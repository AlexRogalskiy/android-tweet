package app.cryptotweets.feed.models.entities

data class Media(val media_url_https: String)
