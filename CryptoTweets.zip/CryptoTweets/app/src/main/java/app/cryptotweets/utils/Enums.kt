package app.cryptotweets.utils

enum class Status {
    LOADING, SUCCESS, ERROR
}