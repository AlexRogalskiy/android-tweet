package app.cryptotweets.feed.models.entities

data class Entities(val media: List<Media>?)